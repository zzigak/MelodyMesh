WORK IN PROGRESS!

Host this code as-is with some live-server functionality (like `npx serve` if you have NodeJS installed on your computer already) and it will just work.
